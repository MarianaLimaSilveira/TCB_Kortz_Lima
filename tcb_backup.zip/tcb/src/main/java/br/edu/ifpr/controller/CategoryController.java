package br.edu.ifpr.controller;

import java.util.List;
import br.edu.ifpr.dao.ArtworkDAO;
import br.edu.ifpr.dao.CategoryDAO;
import br.edu.ifpr.model.Category;

public class CategoryController {

    private CategoryDAO categoryDAO = new CategoryDAO();
    private ArtworkDAO artworkDAO = new ArtworkDAO();

    public void createCategory(Category category) {
        categoryDAO.create(category);
    }

    public List<Category> listCategories() {
        return categoryDAO.readAll();
    }

    public void updateCategory(Category category) {
        categoryDAO.update(category);
    }

    public void deleteCategory(Long categoryId) {
        // Validação de Integridade Referencial:
        // Verifica se a categoria está vinculada a alguma obra ativa no sistema.
        // Se houver vínculo, impede a exclusão para evitar orfãos ou erros no BD.
        boolean categoriaEmUso = artworkDAO.readAll().stream()
                .anyMatch(a -> a.getIdCategory() == categoryId);

        if (categoriaEmUso) {
            System.out.println("Categoria esta em uso por obras e nao pode ser excluida.");
            return;
        }

        categoryDAO.delete(categoryId);
    }
}